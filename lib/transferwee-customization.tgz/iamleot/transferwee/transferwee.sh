#!/bin/bash

#set -x

BASEDIR=$(dirname "$(realpath "$0")") || exit $?
VENV=$BASEDIR/venv

python3 -m venv $VENV || exit $?
source $VENV/bin/activate || exit $?

# Install/upgrade dependencies
ls -d $VENV/lib/python*/site-packages/requests >/dev/null \
    || pip install -r $BASEDIR/requirements.txt\
    || exit $?

# Run the app
# python app.py || exit $?
$BASEDIR/transferwee.py "$@"
